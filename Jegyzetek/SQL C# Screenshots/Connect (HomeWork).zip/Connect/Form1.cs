﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;
using System.Diagnostics;

namespace Connect
{
    public partial class Form1 : Form
    {
        public string connectionString = "Server=localhost;" +
                          "Database=connect;" +
                          "User ID=root;" +
                          "Password=mysql;";

        public Form1()
        {
            InitializeComponent();




        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {

                try
                {
                    conn.Open();
                    string query = "INSERT INTO users (name, birthday, email) VALUES (@name, @birthday, @email)";

                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@name", "John Doe");
                        cmd.Parameters.AddWithValue("@birthday", "2004-10-21");
                        cmd.Parameters.AddWithValue("@email", "miko.balint.miklos@gmail.com");

                        int rowsAffected = cmd.ExecuteNonQuery(); // Executes the query
                        Debug.WriteLine($"{rowsAffected} row(s) inserted.");
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine("Error: " + ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {


            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {

                try
                {
                    conn.Open();
                    Console.WriteLine("Connected to MySQL!");

                    string query = "SELECT * FROM users";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Debug.WriteLine(reader["id"].ToString());
                            Debug.WriteLine(reader["name"].ToString());
                            Debug.WriteLine(reader["birthday"].ToString());
                            Debug.WriteLine(reader["email"].ToString());
                            Debug.WriteLine("");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
            }
        }
    }
}
